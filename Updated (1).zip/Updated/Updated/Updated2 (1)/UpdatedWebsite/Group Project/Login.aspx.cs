﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Group_Project.ServiceReference1;
using HashPass;

namespace Group_Project
{
    public partial class Login : System.Web.UI.Page
    {
        Service1Client sc = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLog_Click(object sender, EventArgs e)
        {

            var hashed = Secrecy.HashPassword(password.Value);
            var tempUser = sc.Login(email.Value, hashed);
            if (tempUser != null)
            {
                Session["UName"] = tempUser.Name.ToString();
                Session["UId"] = tempUser.Id.ToString();
                Session["UEmail"] = tempUser.Email.ToString();
                Session["UCourse"] = tempUser.Course.ToString();
                Session["USurname"] = tempUser.Surname.ToString();

                Response.Redirect("Home.aspx");
            }
            else
            {
                email.Value = null;
                password.Value = null;
                error.Visible = true;
            }
        }
    }
}