﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Group_Project.ServiceReference1;
using HashPass;

namespace Group_Project
{
    public partial class Contact : System.Web.UI.Page
    {
        Service1Client sc = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

      

        protected void btnReg_Click1(object sender, EventArgs e)
        {
            if (password.Value == confirmp.Value)
            {
                var hashed = Secrecy.HashPassword(password.Value);
                var newUser = new User()
                {

                    Name = name.Value,
                    Email = email.Value,
                    Password = hashed,
                    Course = course.Value,
                    Surname = surname.Value,

                };
                int result = sc.Register(newUser);

                if (result == 1)
                {


                    Response.Redirect("Login.aspx");
                }
                else
                {
                    name.Value = null;
                    email.Value = null;
                    surname = null;
                    course.Value = null;
                    password.Value = null;



                    error.Visible = true;
                }
            }
            else
            {
                error.Visible = true;
                error.Text = "Password doesn't match";
            }

        }
    }
}