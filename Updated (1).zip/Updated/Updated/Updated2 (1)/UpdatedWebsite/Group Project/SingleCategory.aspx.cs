﻿using Group_Project.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_Project
{
    public partial class SingleCategory : System.Web.UI.Page
    {
        Service1Client sr = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            String category = Request.QueryString["id"];

            var list = sr.getCategory(category);

            String display = "";
            String display2 = "";

            display2 += "<h3 class='display-4 text-white text - uppercase'>" + category + "</h3>";
            display2 += "<div class='d-inline-flex text-white'>";
            display2 += "<p class='m-0 text-uppercase'><a class='text-white' href='Courses.aspx'>Catalogue</a></p>";
            display2 += "<i class='fa fa-angle-double-right pt-1 px-3'></i>";
            display2 += "<p class='m-0 text-uppercase'>" + category + "</p>";
            display2 += "</div>";

            header.InnerHtml += display2;

            foreach (Book b in list)
            {
                display += "<div class='col-lg-4 col-md-6 mb-4'>";
                display += "<div class='rounded overflow-hidden mb-2'>";
                display += "<img class='img-fluid' src='" + b.img + "'alt=''>";
                display += "<div class='bg-secondary p-4;'>";
                display += "<div class='d-flex justify-content-between mb-3'>";
                //display+=                <small class="m-0"><i class="fa fa-users text-primary mr-2"></i>25 Students</small>
                //display+=                 <small class="m-0"><i class="far fa-clock text-primary mr-2"></i>01h 30m</small>
                display += "</div>";
                display += "<a class='h5' href=''>" + b.Title + "</a>";
                display += "<div class='border-top mt-4 pt-4'>";
                display += "<div class='d-flex justify-content-between'>";
                //display+=                     <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.5 <small>(250)</small></h6>
                display += "<h5 class='m-0'>R99</h5>";
                display += "</div></div></div></div></div>";
            }
            rowBooks.InnerHtml += display;
        }
    }
}