﻿using Group_Project.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_Project
{
    public partial class Courses : System.Web.UI.Page
    {
        Service1Client sr = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            var list = sr.getBooks();

            String display = "";

            //foreach(Book b in list)
            //{
            //    display += "<div class='col-lg-4 col-md-6 mb-4'>";
            //    display += "<div class='rounded overflow-hidden mb-2'>";
            //    display += "<img class='img-fluid' src='" + b.img + "'alt=''>";
            //    display += "<div class='bg-secondary p-4;'>";
            //    display += "<div class='d-flex justify-content-between mb-3'>";
            //    display+= "<small class='m-0''><i class='a fa-users text-primary mr-2'></i>25 Students</small>";
            //    display += "<small class='m-0'><i class='far fa-clock text-primary mr-2'></i>01h 30m</small>";
            //    display += "</div>";
            //    display += "<a class='h5' href=''>" + b.Title + "</a>";
            //    display += "<div class='border-top mt-4 pt-4'>";
            //    display += "<div class='d-flex justify-content-between'>";
            //    //display+=                     <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.5 <small>(250)</small></h6>
            //    display += "<h5>"+b.Price+ "</h5>";
            //    display += "</div></div></div></div></div>";           
            //} 

            foreach(Book l in list)
            {
                display += "<div class='col-lg-4 col-md-6 mb-4'>";
                display += "<div class='rounded overflow-hidden mb-2'>";
               // display += "<img class='mg-fluid' src=" + l.img + " alt=''>";
                display += "<a href='AboutSingleBook.aspx?ID=" + l.Id + "'><img src=" + l.img + " class='mr-3' alt='...'></a>";
                display += "<div class='bg-secondary p-4'>";
                display += "<div class='d-flex justify-content-between mb-3'>";
                
                
                display += "</div>";
                display += "<a class='h5' href=''>" + l.Title + "</a>";
                display += "<div class='border-top mt-4 pt-4'>";
                display += "<div class='d-flex justify-content-between'>";
               
                display += "<h5>"+l.Price+"</h5>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
            }

            rowBooks.InnerHtml += display;
        }
    }
}