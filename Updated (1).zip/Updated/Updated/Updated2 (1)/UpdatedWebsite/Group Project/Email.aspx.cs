﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Group_Project.ServiceReference1;

namespace Group_Project
{
    public partial class Email : System.Web.UI.Page
    {
        Service1Client sc = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnemail_Click(object sender, EventArgs e)
        {
            var emailexits = sc.UserExist(name.Value);

            if (emailexits == 1)
            {
                Session["UMail"] = name.Value;
                Response.Redirect("Password.aspx");

            }
            else
            {
                error.Visible = true;
            }
        }
    }
}