﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Group_Project.ServiceReference1;
using HashPass;

namespace Group_Project
{
    public partial class Password : System.Web.UI.Page
    {
        Service1Client sc = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnPass_Click(object sender, EventArgs e)
        {
            var hashed = Secrecy.HashPassword(pass1.Value);
            if (pass1.Value == Password1.Value)
            {

                var reset = sc.ResetPass(Session["UMail"].ToString(), hashed);
                if (reset == 1)
                {
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    error.Visible = true;
                    pass1.Value = null;
                    Password1.Value = null;
                }
            }
            else
            {
                error.Visible = true;
                pass1.Value = null;
                Password1.Value = null;
            }
        }
    }
}