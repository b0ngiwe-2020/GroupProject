﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_Project
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Session["ID"] = Session.SessionID;

            //int id = Convert.ToInt32(Session["ID"]);
          

            //if (id != null)
            //{
            //    btnLogin.Visible = false;
            //    btnLogout.Visible = true;

            //    if (id == 1)
            //    {
            //        edit.Visible = true;
            //        add.Visible = true;
            //    }
            //}
            //else
            //{
            //    Session["ID"] = -1;
            //    btnLogin.Visible = true;
            //    btnLogout.Visible = false;
            //}
           
        }
    }
}