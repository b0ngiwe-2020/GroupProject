﻿using Group_Project.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Group_Project
{
    public partial class AboutSingleBook : System.Web.UI.Page
    {

        Service1Client sr = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ID"] == null)
            {
                Response.Redirect("Home.aspx");
            }
            else
            {
                //retrive the URL parameter.
                int Id = Convert.ToInt32(Request.QueryString["ID"]);
                String display = "";
                var book = sr.getBook(Id);

                display += "<div class='container-fluid py-5'>";
                display += "<div class='container py-5'>";
                display += "<div class='row'>";
                display += "<div class='col -lg-8'>";
                display += "<div class='mb -5'>";
                display += "<img class='img -fluid rounded w-50 float-left mr-4 mb-3' src='" + book.img + "' alt='Image'>";
                display += "</div>";
                display += "<div class='about_text'>";
                display += "<h4>" + book.Title + "</h4>";
                display += "<p>" + book.Description + "</p>";
                display += "<p> " + book.Price + "</p>";
                display += "<h6> " + book.Condition + "</h6>";
                display += "<h7> " + book.Category + "</h7>";
                display += "<p> " + book.Author + "</p>";
                display += "</div>";
                display += "</div>";
                display += "<div class='form -group mb - 0'>";
                display += "<input type ='submit' value='Leave Comment' class='btn btn-primary py-md-2 px-md-4 font-weight-semi-bold'>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                display += "</div>";
                abouts.InnerHtml = display;
            }    }
    }
}